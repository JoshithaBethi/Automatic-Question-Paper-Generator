"""
app.py
-------
Entry point of the AI-Based MCQ Question Paper Generator.
Run with:  python app.py
Then open: http://127.0.0.1:5000
Default login -> username: admin | password: admin123
"""

import os
from flask import Flask
from config import Config
from database.db import init_db

from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.upload import upload_bp
from routes.exam import exam_bp
from routes.papers import papers_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Make sure required folders exist
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(Config.GENERATED_FOLDER, exist_ok=True)
    os.makedirs(os.path.dirname(Config.DATABASE_PATH), exist_ok=True)

    # Initialize database tables + default teacher account
    init_db()

    # Register all module blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(upload_bp)
    app.register_blueprint(exam_bp)
    app.register_blueprint(papers_bp)

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
