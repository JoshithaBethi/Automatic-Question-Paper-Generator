// script.js - small UI helper behaviors

document.addEventListener("DOMContentLoaded", function () {
  // Mobile sidebar toggle
  const toggleBtn = document.getElementById("sidebarToggle");
  const sidebar = document.querySelector(".sidebar");
  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener("click", function () {
      sidebar.classList.toggle("show");
    });
  }

  // Live search filter on the Previous Papers table
  const searchInput = document.getElementById("paperSearch");
  const table = document.getElementById("papersTable");
  if (searchInput && table) {
    searchInput.addEventListener("keyup", function () {
      const term = this.value.toLowerCase();
      const rows = table.querySelectorAll("tbody tr");
      rows.forEach((row) => {
        row.style.display = row.textContent.toLowerCase().includes(term) ? "" : "none";
      });
    });
  }

  // Auto-dismiss flash messages after 4 seconds
  document.querySelectorAll(".alert").forEach((alertEl) => {
    setTimeout(() => {
      alertEl.classList.remove("show");
    }, 4000);
  });
});
