"""
config.py
----------
Central configuration for the AI-Based MCQ Question Paper Generator.
Keeping configuration in one place makes the project easy to maintain
and easy to explain during a viva.
"""

import os

# Base directory of the project (folder where this file lives)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    # Secret key is used by Flask to secure sessions (login sessions, flash messages)
    SECRET_KEY = "mcq_generator_secret_key_2026"  # change this before real deployment

    # SQLite database file path
    DATABASE_PATH = os.path.join(BASE_DIR, "database", "mcq_app.db")

    # Folder where uploaded syllabus files (PDF/DOCX) are stored
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")

    # Folder where generated question paper / answer key PDFs are stored
    GENERATED_FOLDER = os.path.join(BASE_DIR, "generated_papers")

    # Allowed file extensions for syllabus upload
    ALLOWED_EXTENSIONS = {"pdf", "docx"}

    # College name printed on the generated question paper header
    COLLEGE_NAME = "ABC COLLEGE OF ENGINEERING & TECHNOLOGY"

    # Max upload size (5 MB) - prevents accidental huge file uploads
    MAX_CONTENT_LENGTH = 5 * 1024 * 1024
