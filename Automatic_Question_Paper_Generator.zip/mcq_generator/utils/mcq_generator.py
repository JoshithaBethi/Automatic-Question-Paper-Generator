"""
mcq_generator.py
-----------------
Module 5: AI Question Generator.

This is the "AI" core of the project. It uses classic NLP techniques
(no external paid API is needed, so the project runs fully offline):

  1. Clean the syllabus text and split it into sentences.
  2. Score every candidate keyword by frequency + word-length
     (a simple, well known "term importance" heuristic used in
     keyword-extraction / text-mining, similar in spirit to TF scoring).
  3. Pick sentences that contain an important keyword -> turn the
     keyword into a blank -> that becomes the MCQ question stem.
  4. Build 3 wrong options (distractors) from other extracted keywords.
  5. Filter sentence choice by difficulty (Easy = short/simple
     sentences, Hard = long/technical sentences).
  6. Avoid duplicate questions and duplicate keywords.

This keeps the project simple enough for a 3rd-year student to explain,
while still being a genuine automated, rule-based "AI" pipeline.
"""

import re
import random

# Common English stopwords to ignore while extracting keywords
STOPWORDS = set("""
a an the and or but if while is are was were be been being to of in on
for with as by at from this that these those it its it's their his her
they them we you your our i he she not no can may might will would
shall should must into over under between within without across per also
such etc each other than then there here what which who whom when where
why how all any some more most many much few less least own same so
""".split())


def clean_text(text):
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def split_sentences(text):
    """Very simple sentence splitter based on punctuation."""
    text = clean_text(text)
    sentences = re.split(r"(?<=[.!?])\s+", text)
    # keep only meaningful sentences (avoid headers, page numbers, etc.)
    sentences = [s.strip() for s in sentences if len(s.split()) >= 6]
    return sentences


def extract_keywords(text, top_n=60):
    """Extract candidate 'important terms' using a frequency + length
    heuristic. Longer, less common words are usually more subject-specific
    (e.g. 'polymorphism', 'inheritance') and make good MCQ answers.
    """
    words = re.findall(r"[A-Za-z]{4,}", text)
    freq = {}
    for w in words:
        lw = w.lower()
        if lw in STOPWORDS:
            continue
        freq[lw] = freq.get(lw, 0) + 1

    # Score = frequency * word length (favors meaningful technical terms)
    scored = sorted(freq.items(), key=lambda x: (x[1] * len(x[0])), reverse=True)
    keywords = [w for w, _ in scored[:top_n]]
    return keywords


def difficulty_filter(sentences, difficulty):
    """Filter/sort sentences by length depending on difficulty level."""
    difficulty = difficulty.lower()
    if difficulty == "easy":
        return sorted(sentences, key=lambda s: len(s.split()))
    elif difficulty == "hard":
        return sorted(sentences, key=lambda s: len(s.split()), reverse=True)
    else:  # medium -> keep natural order, prefer mid-length sentences
        return sorted(sentences, key=lambda s: abs(len(s.split()) - 15))


def find_keyword_in_sentence(sentence, keywords, used_keywords):
    """Return the first unused keyword that appears as a whole word
    inside the sentence, or None if no match is found.
    """
    lower_sentence = sentence.lower()
    for kw in keywords:
        if kw in used_keywords:
            continue
        if re.search(r"\b" + re.escape(kw) + r"\b", lower_sentence):
            return kw
    return None


def build_question_stem(sentence, keyword):
    """Replace the keyword in the sentence with a blank to form the
    question stem. Case-insensitive whole-word replacement.
    """
    pattern = re.compile(r"\b" + re.escape(keyword) + r"\b", re.IGNORECASE)
    stem = pattern.sub("______", sentence, count=1)
    return stem


def generate_mcqs(syllabus_text, num_questions=10, difficulty="Medium"):
    """
    Main entry point used by the Flask route.

    Returns a list of dicts:
        {
          "question": "...",
          "options": {"A": "...", "B": "...", "C": "...", "D": "..."},
          "answer": "A"
        }
    """
    sentences = split_sentences(syllabus_text)
    sentences = difficulty_filter(sentences, difficulty)
    keywords = extract_keywords(syllabus_text)

    if not keywords or not sentences:
        return []

    questions = []
    used_keywords = set()
    used_sentences = set()

    for sentence in sentences:
        if len(questions) >= num_questions:
            break
        if sentence in used_sentences:
            continue

        keyword = find_keyword_in_sentence(sentence, keywords, used_keywords)
        if not keyword:
            continue

        # Build distractors: 3 other keywords, not equal to the answer
        distractor_pool = [k for k in keywords if k != keyword and k not in used_keywords]
        if len(distractor_pool) < 3:
            continue
        distractors = random.sample(distractor_pool, 3)

        options_list = [keyword] + distractors
        random.shuffle(options_list)

        labels = ["A", "B", "C", "D"]
        options = {labels[i]: options_list[i].capitalize() for i in range(4)}
        correct_label = labels[options_list.index(keyword)]

        question_stem = build_question_stem(sentence, keyword)

        questions.append({
            "question": f"Fill in the blank: {question_stem}",
            "options": options,
            "answer": correct_label,
        })

        used_keywords.add(keyword)
        used_sentences.add(sentence)

    return questions
