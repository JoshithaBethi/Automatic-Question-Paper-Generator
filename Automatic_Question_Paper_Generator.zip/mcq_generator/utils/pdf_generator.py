"""
pdf_generator.py
-----------------
Module 7: Download.
Creates the Question Paper PDF and the Answer Key PDF using ReportLab.
"""

import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from config import Config


def _base_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="CollegeHeader", fontSize=16, alignment=1, spaceAfter=4, leading=20,
    ))
    styles.add(ParagraphStyle(
        name="ExamTitle", fontSize=13, alignment=1, spaceAfter=10, leading=16,
    ))
    styles.add(ParagraphStyle(
        name="MetaLine", fontSize=10, alignment=1, spaceAfter=12,
    ))
    styles.add(ParagraphStyle(
        name="Question", fontSize=11, spaceBefore=8, spaceAfter=2, leading=15,
    ))
    styles.add(ParagraphStyle(
        name="Option", fontSize=10.5, leftIndent=14, spaceAfter=1, leading=14,
    ))
    return styles


def generate_question_paper_pdf(subject, exam_title, questions, marks_per_question, output_path):
    """Creates the student-facing question paper (no answers shown)."""
    styles = _base_styles()
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                             topMargin=18 * mm, bottomMargin=18 * mm,
                             leftMargin=18 * mm, rightMargin=18 * mm)
    elements = []

    total_marks = marks_per_question * len(questions)

    elements.append(Paragraph(Config.COLLEGE_NAME, styles["CollegeHeader"]))
    elements.append(Paragraph(exam_title, styles["ExamTitle"]))
    elements.append(Paragraph(
        f"Subject: {subject} &nbsp;&nbsp;|&nbsp;&nbsp; "
        f"Total Questions: {len(questions)} &nbsp;&nbsp;|&nbsp;&nbsp; "
        f"Total Marks: {total_marks}",
        styles["MetaLine"]
    ))
    elements.append(Paragraph(
        "<b>Instructions:</b> All questions are compulsory. Each question carries "
        f"{marks_per_question} mark(s). Choose the most appropriate option (A, B, C or D).",
        styles["Normal"]
    ))
    elements.append(Spacer(1, 10))

    for i, q in enumerate(questions, start=1):
        elements.append(Paragraph(f"Q{i}. {q['question']}", styles["Question"]))
        for label in ["A", "B", "C", "D"]:
            elements.append(Paragraph(f"({label}) {q['options'][label]}", styles["Option"]))

    doc.build(elements)
    return output_path


def generate_answer_key_pdf(subject, exam_title, questions, output_path):
    """Creates the answer key PDF listing the correct option for each question."""
    styles = _base_styles()
    doc = SimpleDocTemplate(output_path, pagesize=A4,
                             topMargin=18 * mm, bottomMargin=18 * mm,
                             leftMargin=18 * mm, rightMargin=18 * mm)
    elements = []

    elements.append(Paragraph(Config.COLLEGE_NAME, styles["CollegeHeader"]))
    elements.append(Paragraph(f"Answer Key - {exam_title}", styles["ExamTitle"]))
    elements.append(Paragraph(f"Subject: {subject}", styles["MetaLine"]))
    elements.append(Spacer(1, 8))

    table_data = [["Q.No.", "Correct Option", "Correct Answer"]]
    for i, q in enumerate(questions, start=1):
        table_data.append([str(i), q["answer"], q["options"][q["answer"]]])

    table = Table(table_data, colWidths=[60, 110, 300])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f2f2f2")]),
        ("ALIGN", (0, 0), (0, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    elements.append(table)

    doc.build(elements)
    return output_path
