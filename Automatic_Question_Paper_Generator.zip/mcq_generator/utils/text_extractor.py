"""
text_extractor.py
------------------
Module 3 support: Extracts raw text from an uploaded syllabus file.
Supports PDF (using pdfplumber) and DOCX (using python-docx).
"""

import pdfplumber
import docx


def extract_text_from_pdf(filepath):
    """Read every page of the PDF and join the text together."""
    text_parts = []
    with pdfplumber.open(filepath) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text_parts.append(page_text)
    return "\n".join(text_parts)


def extract_text_from_docx(filepath):
    """Read every paragraph of the Word document."""
    document = docx.Document(filepath)
    paragraphs = [p.text for p in document.paragraphs if p.text.strip()]
    return "\n".join(paragraphs)


def extract_text(filepath, extension):
    """Route to the correct extractor based on file extension."""
    extension = extension.lower()
    if extension == "pdf":
        return extract_text_from_pdf(filepath)
    elif extension == "docx":
        return extract_text_from_docx(filepath)
    else:
        raise ValueError("Unsupported file type: " + extension)
