-- schema.sql
-- ----------------------------------------------------------------
-- Database schema for AI-Based MCQ Question Paper Generator
-- Only 3 tables are needed since there is no student module.
-- ----------------------------------------------------------------

-- Table 1: Teachers (login credentials)
CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL          -- stored as a secure hash, never plain text
);

-- Table 2: Uploaded_Syllabus (tracks every syllabus file uploaded)
CREATE TABLE IF NOT EXISTS uploaded_syllabus (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject TEXT NOT NULL,
    filename TEXT NOT NULL,
    extracted_text TEXT,             -- text extracted from the PDF/DOCX, reused by the generator
    upload_date TEXT NOT NULL
);

-- Table 3: Generated_Papers (tracks every MCQ paper generated)
CREATE TABLE IF NOT EXISTS generated_papers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject TEXT NOT NULL,
    exam_title TEXT NOT NULL,
    difficulty TEXT NOT NULL,
    number_of_questions INTEGER NOT NULL,
    marks_per_question INTEGER DEFAULT 1,
    generated_date TEXT NOT NULL,
    question_pdf_path TEXT,
    answer_pdf_path TEXT,
    questions_json TEXT               -- full question+options+answer data, stored as JSON text
);
