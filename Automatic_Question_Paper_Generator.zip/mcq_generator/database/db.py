"""
db.py
------
Handles all SQLite database connection and initialization logic.
Using a single helper module keeps SQL code out of the route files
(this is called "separation of concerns").
"""

import sqlite3
import os
from werkzeug.security import generate_password_hash
from config import Config


def get_connection():
    """Create and return a new SQLite connection.
    row_factory lets us access columns by name, e.g. row['username'].
    """
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create tables (if they do not already exist) and seed a default
    teacher account so the project can be demoed immediately.
    """
    os.makedirs(os.path.dirname(Config.DATABASE_PATH), exist_ok=True)
    conn = get_connection()
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")

    with open(schema_path, "r") as f:
        conn.executescript(f.read())

    # Seed one default teacher account: username=admin, password=admin123
    cur = conn.cursor()
    cur.execute("SELECT * FROM teachers WHERE username = ?", ("admin",))
    if cur.fetchone() is None:
        hashed_pw = generate_password_hash("admin123")
        cur.execute(
            "INSERT INTO teachers (username, password) VALUES (?, ?)",
            ("admin", hashed_pw),
        )
        conn.commit()

    conn.close()
