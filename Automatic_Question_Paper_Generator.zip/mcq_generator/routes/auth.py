"""
auth.py
--------
Module 1: Teacher Login.
Handles login, logout, and the "logged in" check used to protect
every other page in the app.
"""

from functools import wraps
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash
from database.db import get_connection

auth_bp = Blueprint("auth", __name__)


def login_required(view_func):
    """Decorator used on every protected route (dashboard, upload, etc.)."""
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if "teacher_id" not in session:
            flash("Please login to continue.", "error")
            return redirect(url_for("auth.login"))
        return view_func(*args, **kwargs)
    return wrapped


@auth_bp.route("/", methods=["GET"])
def index():
    return redirect(url_for("auth.login"))


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        conn = get_connection()
        teacher = conn.execute(
            "SELECT * FROM teachers WHERE username = ?", (username,)
        ).fetchone()
        conn.close()

        if teacher and check_password_hash(teacher["password"], password):
            session["teacher_id"] = teacher["id"]
            session["username"] = teacher["username"]
            return redirect(url_for("dashboard.home"))
        else:
            flash("Invalid Username or Password.", "error")

    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out successfully.", "success")
    return redirect(url_for("auth.login"))
