"""
dashboard.py
-------------
Module 2: Dashboard - the landing page after login, showing quick stats.
"""

from flask import Blueprint, render_template, session
from database.db import get_connection
from routes.auth import login_required

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/dashboard")
@login_required
def home():
    conn = get_connection()
    total_papers = conn.execute("SELECT COUNT(*) AS c FROM generated_papers").fetchone()["c"]
    total_uploads = conn.execute("SELECT COUNT(*) AS c FROM uploaded_syllabus").fetchone()["c"]
    recent_papers = conn.execute(
        "SELECT * FROM generated_papers ORDER BY id DESC LIMIT 5"
    ).fetchall()
    conn.close()

    return render_template(
        "dashboard.html",
        username=session.get("username"),
        total_papers=total_papers,
        total_uploads=total_uploads,
        recent_papers=recent_papers,
    )
