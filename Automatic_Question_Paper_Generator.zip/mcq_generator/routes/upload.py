"""
upload.py
----------
Module 3: Upload Syllabus.
Accepts a PDF/DOCX file, saves it, extracts its text, and stores
the result in the uploaded_syllabus table so later steps can reuse it.
"""

import os
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from werkzeug.utils import secure_filename
from database.db import get_connection
from routes.auth import login_required
from utils.text_extractor import extract_text
from config import Config

upload_bp = Blueprint("upload", __name__)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS


@upload_bp.route("/upload", methods=["GET", "POST"])
@login_required
def upload_syllabus():
    if request.method == "POST":
        subject = request.form.get("subject", "").strip()
        file = request.files.get("syllabus_file")

        if not subject:
            flash("Please enter a subject name.", "error")
            return redirect(url_for("upload.upload_syllabus"))

        if not file or file.filename == "":
            flash("Please choose a PDF or DOCX file.", "error")
            return redirect(url_for("upload.upload_syllabus"))

        if not allowed_file(file.filename):
            flash("Only PDF and DOCX files are allowed.", "error")
            return redirect(url_for("upload.upload_syllabus"))

        filename = secure_filename(file.filename)
        # prefix with timestamp so two uploads never overwrite each other
        stored_name = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{filename}"
        filepath = os.path.join(Config.UPLOAD_FOLDER, stored_name)
        file.save(filepath)

        extension = filename.rsplit(".", 1)[1].lower()
        try:
            extracted_text = extract_text(filepath, extension)
        except Exception as e:
            flash(f"Could not read file: {e}", "error")
            return redirect(url_for("upload.upload_syllabus"))

        if not extracted_text or len(extracted_text.split()) < 30:
            flash("Could not extract enough text from this file. Try another file.", "error")
            return redirect(url_for("upload.upload_syllabus"))

        conn = get_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO uploaded_syllabus (subject, filename, extracted_text, upload_date) "
            "VALUES (?, ?, ?, ?)",
            (subject, stored_name, extracted_text, datetime.now().strftime("%Y-%m-%d %H:%M")),
        )
        syllabus_id = cur.lastrowid
        conn.commit()
        conn.close()

        flash("Syllabus uploaded and text extracted successfully.", "success")
        return redirect(url_for("exam.exam_settings", syllabus_id=syllabus_id))

    return render_template("upload.html")
