"""
papers.py
----------
Module 7: Download (generates the PDFs and saves paper record to DB).
Module 8: Previous Papers (lists all previously generated papers).
"""

import os
import json
from datetime import datetime
from flask import (
    Blueprint, render_template, redirect, url_for, flash, session, send_from_directory
)
from database.db import get_connection
from routes.auth import login_required
from utils.pdf_generator import generate_question_paper_pdf, generate_answer_key_pdf
from config import Config

papers_bp = Blueprint("papers", __name__)


@papers_bp.route("/finalize-download")
@login_required
def finalize_and_download():
    """Called from the Preview page's 'Download PDF' button.
    Generates both PDFs, stores the record in DB, then shows the
    Previous Papers page with fresh download links.
    """
    paper = session.get("pending_paper")
    if not paper:
        flash("No paper available. Please generate one first.", "error")
        return redirect(url_for("upload.upload_syllabus"))

    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    safe_subject = "".join(c for c in paper["subject"] if c.isalnum()) or "subject"

    question_pdf_name = f"{safe_subject}_{timestamp}_questionpaper.pdf"
    answer_pdf_name = f"{safe_subject}_{timestamp}_answerkey.pdf"

    question_pdf_path = os.path.join(Config.GENERATED_FOLDER, question_pdf_name)
    answer_pdf_path = os.path.join(Config.GENERATED_FOLDER, answer_pdf_name)

    generate_question_paper_pdf(
        paper["subject"], paper["exam_title"], paper["questions"],
        paper["marks_per_question"], question_pdf_path
    )
    generate_answer_key_pdf(
        paper["subject"], paper["exam_title"], paper["questions"], answer_pdf_path
    )

    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        """INSERT INTO generated_papers
           (subject, exam_title, difficulty, number_of_questions, marks_per_question,
            generated_date, question_pdf_path, answer_pdf_path, questions_json)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            paper["subject"], paper["exam_title"], paper["difficulty"],
            len(paper["questions"]), paper["marks_per_question"],
            datetime.now().strftime("%Y-%m-%d %H:%M"),
            question_pdf_name, answer_pdf_name, json.dumps(paper["questions"]),
        ),
    )
    conn.commit()
    conn.close()

    session.pop("pending_paper", None)
    flash("Question paper and answer key generated successfully!", "success")
    return redirect(url_for("papers.previous_papers"))


@papers_bp.route("/previous-papers")
@login_required
def previous_papers():
    conn = get_connection()
    papers = conn.execute(
        "SELECT * FROM generated_papers ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return render_template("previous_papers.html", papers=papers)


@papers_bp.route("/download/<path:filename>")
@login_required
def download_file(filename):
    return send_from_directory(Config.GENERATED_FOLDER, filename, as_attachment=True)
