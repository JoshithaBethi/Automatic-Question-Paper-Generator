"""
exam.py
--------
Module 4: Exam Settings  (teacher enters subject/title/difficulty/count)
Module 5: AI Question Generator (calls utils/mcq_generator.py)
Module 6: Preview (shows generated paper, allows regenerate)
"""

import json
from datetime import datetime
from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, session
)
from database.db import get_connection
from routes.auth import login_required
from utils.mcq_generator import generate_mcqs

exam_bp = Blueprint("exam", __name__)


@exam_bp.route("/exam-settings/<int:syllabus_id>", methods=["GET", "POST"])
@login_required
def exam_settings(syllabus_id):
    conn = get_connection()
    syllabus = conn.execute(
        "SELECT * FROM uploaded_syllabus WHERE id = ?", (syllabus_id,)
    ).fetchone()
    conn.close()

    if syllabus is None:
        flash("Syllabus not found. Please upload again.", "error")
        return redirect(url_for("upload.upload_syllabus"))

    if request.method == "POST":
        exam_title = request.form.get("exam_title", "").strip()
        difficulty = request.form.get("difficulty", "Medium")
        num_questions = int(request.form.get("num_questions", 10))
        marks_per_question = int(request.form.get("marks_per_question", 1))

        if not exam_title:
            flash("Please enter an exam title.", "error")
            return redirect(url_for("exam.exam_settings", syllabus_id=syllabus_id))

        return redirect(url_for(
            "exam.generate_paper",
            syllabus_id=syllabus_id,
            exam_title=exam_title,
            difficulty=difficulty,
            num_questions=num_questions,
            marks_per_question=marks_per_question,
        ))

    return render_template("exam_settings.html", syllabus=syllabus)


@exam_bp.route("/generate-paper/<int:syllabus_id>")
@login_required
def generate_paper(syllabus_id):
    exam_title = request.args.get("exam_title")
    difficulty = request.args.get("difficulty", "Medium")
    num_questions = int(request.args.get("num_questions", 10))
    marks_per_question = int(request.args.get("marks_per_question", 1))

    conn = get_connection()
    syllabus = conn.execute(
        "SELECT * FROM uploaded_syllabus WHERE id = ?", (syllabus_id,)
    ).fetchone()
    conn.close()

    if syllabus is None:
        flash("Syllabus not found. Please upload again.", "error")
        return redirect(url_for("upload.upload_syllabus"))

    questions = generate_mcqs(
        syllabus["extracted_text"],
        num_questions=num_questions,
        difficulty=difficulty,
    )

    if not questions:
        flash("Could not generate MCQs from this syllabus. Try a longer/more detailed file.", "error")
        return redirect(url_for("upload.upload_syllabus"))

    if len(questions) < num_questions:
        flash(
            f"Only {len(questions)} unique MCQs could be generated from this syllabus "
            f"(requested {num_questions}).",
            "info",
        )

    # Keep everything needed for preview/download in the session temporarily
    session["pending_paper"] = {
        "subject": syllabus["subject"],
        "exam_title": exam_title,
        "difficulty": difficulty,
        "marks_per_question": marks_per_question,
        "questions": questions,
        "syllabus_id": syllabus_id,
    }

    return redirect(url_for("exam.preview_paper"))


@exam_bp.route("/preview")
@login_required
def preview_paper():
    paper = session.get("pending_paper")
    if not paper:
        flash("No paper to preview. Please generate one first.", "error")
        return redirect(url_for("upload.upload_syllabus"))
    return render_template("preview.html", paper=paper)


@exam_bp.route("/regenerate")
@login_required
def regenerate():
    paper = session.get("pending_paper")
    if not paper:
        flash("Nothing to regenerate.", "error")
        return redirect(url_for("upload.upload_syllabus"))

    return redirect(url_for(
        "exam.generate_paper",
        syllabus_id=paper["syllabus_id"],
        exam_title=paper["exam_title"],
        difficulty=paper["difficulty"],
        num_questions=len(paper["questions"]),
        marks_per_question=paper["marks_per_question"],
    ))
