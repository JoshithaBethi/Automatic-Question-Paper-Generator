# AI-Based MCQ Question Paper Generator

A 3rd-year B.Tech mini project. A Flask web application that lets a teacher
upload a syllabus (PDF/DOCX), automatically generates multiple-choice
questions from it using an NLP-based "AI" pipeline, and produces a
downloadable Question Paper PDF and Answer Key PDF.

---

## 1. Abstract

Preparing question papers manually is time-consuming for teachers, who must
read through the syllabus, frame questions, design plausible wrong options,
and format everything into a presentable paper. This project automates that
process end-to-end.

A teacher logs in, uploads a syllabus file, and enters exam details
(title, difficulty, number of questions, marks). The system extracts text
from the file, analyzes it using a keyword-extraction and sentence-scoring
algorithm to identify important concepts, and automatically builds
multiple-choice questions with four options and a marked correct answer.
The teacher can preview the paper, regenerate it if unsatisfied, and then
download a formatted Question Paper PDF and a separate Answer Key PDF.
Every generated paper is logged in a database so it can be revisited later.

The project does not use any paid third-party AI API — the "AI" component
is a self-contained, offline NLP pipeline (frequency-based keyword
extraction + sentence scoring), making the system free to run, easy to
explain, and suitable for a college mini-project demonstration.

---

## 2. Technology Stack

| Layer      | Technology                          |
|------------|--------------------------------------|
| Frontend   | HTML5, CSS3, Bootstrap 5, JavaScript |
| Backend    | Python 3, Flask                      |
| Database   | SQLite                               |
| PDF Read   | pdfplumber                           |
| DOCX Read  | python-docx                          |
| PDF Write  | ReportLab                            |
| Auth       | Flask session + Werkzeug password hashing |

---

## 3. Project Folder Structure

```
mcq_generator/
├── app.py                     # Flask entry point, registers all blueprints
├── config.py                  # App-wide configuration (paths, secret key)
├── requirements.txt
├── database/
│   ├── schema.sql             # CREATE TABLE statements
│   └── db.py                  # connection + init_db() + default admin seed
├── routes/                    # One blueprint per module
│   ├── auth.py                 # Module 1: Login/Logout
│   ├── dashboard.py             # Module 2: Dashboard
│   ├── upload.py                 # Module 3: Upload Syllabus
│   ├── exam.py                    # Modules 4,5,6: Settings/Generate/Preview
│   └── papers.py                   # Modules 7,8: Download/Previous Papers
├── utils/
│   ├── text_extractor.py      # PDF/DOCX -> raw text
│   ├── mcq_generator.py       # The "AI" NLP MCQ generation engine
│   └── pdf_generator.py       # ReportLab PDF building
├── templates/                 # Jinja2 HTML templates (Bootstrap 5 UI)
├── static/
│   ├── css/style.css
│   └── js/script.js
├── uploads/                   # Stores uploaded syllabus files
└── generated_papers/          # Stores generated PDF output
```

**Why this structure?** Each module in the original specification maps to
exactly one file, so a student can open `routes/upload.py` and see only
upload-related logic — a very common, easy-to-explain Flask pattern called
the **Blueprint pattern**.

---

## 4. Database Schema

```sql
teachers (id, username, password)
uploaded_syllabus (id, subject, filename, extracted_text, upload_date)
generated_papers (id, subject, exam_title, difficulty, number_of_questions,
                   marks_per_question, generated_date,
                   question_pdf_path, answer_pdf_path, questions_json)
```

Full statements are in `database/schema.sql`. `questions_json` stores the
complete question/option/answer data as JSON text so a paper can be
re-displayed without re-running the generator.

### Entity Relationship Diagram

```
┌───────────────┐        ┌────────────────────┐        ┌──────────────────────┐
│   teachers    │        │ uploaded_syllabus  │        │  generated_papers    │
├───────────────┤        ├────────────────────┤        ├──────────────────────┤
│ PK id         │        │ PK id              │        │ PK id                │
│    username   │        │    subject         │        │    subject           │
│    password   │        │    filename        │        │    exam_title        │
└───────────────┘        │    extracted_text  │        │    difficulty        │
        │                │    upload_date     │        │    number_of_questions│
        │ 1                └────────────────────┘        │    marks_per_question│
        │                          │ 1                    │    generated_date    │
        │ generates                │ used to generate      │    question_pdf_path │
        └──────────────►  (session) └───────────────►      │    answer_pdf_path   │
                                                             │    questions_json    │
                                                             └──────────────────────┘
```
*(Note: `uploaded_syllabus` and `generated_papers` are linked logically
through the generation workflow/session rather than a hard foreign key,
since one syllabus can be used to generate several different papers at
different difficulty levels.)*

---

## 5. Use Case Diagram (textual)

```
                     ┌─────────────────────────────┐
                     │   AI MCQ Paper Generator     │
                     │                              │
   ┌────────┐        │  ( Login )                   │
   │        │────────┼─►( Upload Syllabus )          │
   │Teacher │────────┼─►( Set Exam Parameters )      │
   │(Actor) │────────┼─►( Generate MCQs )            │
   │        │────────┼─►( Preview Paper )            │
   │        │────────┼─►( Regenerate Paper )         │
   │        │────────┼─►( Download Question PDF )    │
   │        │────────┼─►( Download Answer Key PDF )  │
   │        │────────┼─►( View Previous Papers )     │
   │        │────────┼─►( Logout )                   │
   └────────┘        └─────────────────────────────┘
```
Only one actor exists: **Teacher**. There is no student actor/module.

---

## 6. Data Flow Diagrams

### DFD Level 0 (Context Diagram)

```
                 syllabus file, exam settings
   ┌─────────┐ ────────────────────────────────► ┌───────────────────────┐
   │ Teacher │                                    │  AI MCQ Question       │
   │         │ ◄──────────────────────────────── │  Paper Generator System│
   └─────────┘   question paper PDF, answer key    └───────────────────────┘
```

### DFD Level 1

```
 Teacher
    │ 1. login credentials
    ▼
[1.0 Authenticate Teacher] ──► teachers (DB)
    │ session created
    ▼
[2.0 Upload & Extract Syllabus] ──► uploaded_syllabus (DB)
    │ extracted text
    ▼
[3.0 Set Exam Parameters]   (subject, title, difficulty, count, marks)
    │
    ▼
[4.0 Generate MCQs]  <── uses extracted text + parameters
    │ list of questions
    ▼
[5.0 Preview / Regenerate]
    │ approved question set
    ▼
[6.0 Generate PDFs] ──► generated_papers (DB)
    │
    ▼
 Teacher receives Question Paper PDF + Answer Key PDF

[7.0 View Previous Papers] ◄── generated_papers (DB)
```

---

## 7. System Flowchart

```
        START
          │
          ▼
   ┌─────────────┐
   │ Teacher Login│
   └──────┬───────┘
          │ valid?
     No ──┼── Yes
    (retry)     ▼
          ┌─────────────┐
          │  Dashboard   │
          └──────┬───────┘
                 ▼
          ┌─────────────────┐
          │ Upload Syllabus  │
          │ (PDF/DOCX)       │
          └──────┬───────────┘
                 ▼
          ┌───────────────────┐
          │ Extract Text       │
          └──────┬─────────────┘
                 ▼
          ┌───────────────────────┐
          │ Enter Exam Settings    │
          │ (title, difficulty,    │
          │  count, marks)         │
          └──────┬─────────────────┘
                 ▼
          ┌────────────────────────┐
          │ AI generates MCQs       │
          │ (keyword + sentence     │
          │  based NLP algorithm)   │
          └──────┬──────────────────┘
                 ▼
          ┌───────────────┐   No, regenerate
          │ Preview Paper  │◄────────────────┐
          └──────┬─────────┘                  │
                 │ satisfied?                  │
                 ▼ Yes                          │
          ┌────────────────────┐                │
          │ Generate PDFs +      │───────────────┘
          │ Save to Database     │
          └──────┬────────────────┘
                 ▼
          ┌─────────────────────┐
          │ Download Question    │
          │ Paper & Answer Key    │
          └──────┬─────────────────┘
                 ▼
              Logout
                 │
                 ▼
               END
```

---

## 8. How the "AI" MCQ Generator Works (`utils/mcq_generator.py`)

1. **Clean & split** the syllabus text into sentences (min. 6 words each,
   to skip page numbers/headers).
2. **Extract keywords**: count word frequency, ignore stopwords, and score
   each word as `frequency × word length` — longer, repeated technical
   words (e.g. "polymorphism") naturally score higher than filler words.
3. **Filter by difficulty**:
   - Easy → shorter sentences first
   - Medium → sentences closest to ~15 words
   - Hard → longest/most complex sentences first
4. For each candidate sentence, find an unused keyword inside it and
   **blank it out** to form the question stem (`Fill in the blank: ...`).
5. Build **3 distractor options** from other extracted keywords, shuffle
   all 4 options, and record which label (A/B/C/D) is correct.
6. Track used sentences/keywords to **avoid duplicate questions**.

This is a rule-based/statistical NLP technique (similar in spirit to
TF-based keyword extraction used in real text-mining tools), so it runs
completely offline with no external API key required.

---

## 9. Setup & Run Instructions

```bash
# 1. Create and activate a virtual environment (recommended)
python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # macOS/Linux

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the application
python app.py

# 4. Open in browser
http://127.0.0.1:5000

# Default login
username: admin
password: admin123
```
The SQLite database and folders are created automatically on first run.

---

## 10. Testing

| Test Case                                   | Input                                | Expected Result                              | Status |
|----------------------------------------------|---------------------------------------|-----------------------------------------------|--------|
| Valid login                                   | admin / admin123                      | Redirect to Dashboard                          | Pass |
| Invalid login                                 | admin / wrongpass                     | "Invalid Username or Password."                | Pass |
| Upload unsupported file type                  | .txt file                             | Error: only PDF/DOCX allowed                   | Pass |
| Upload valid DOCX syllabus                    | sample_syllabus.docx                  | Text extracted, redirected to Exam Settings    | Pass |
| Generate MCQs (Medium, 6 Qs)                  | subject text with 10 concept sentences| 6 valid MCQs generated with 4 options each     | Pass |
| Preview page                                  | generated paper                       | All questions/options rendered correctly       | Pass |
| Regenerate paper                              | click Regenerate                      | New set of MCQs produced                       | Pass |
| Download PDFs                                 | click Download PDF                    | Question Paper PDF + Answer Key PDF created     | Pass |
| View previous papers                          | navigate to Previous Papers           | Table lists paper with working download links  | Pass |
| Search previous papers                        | type subject in search box            | Table filters in real time                     | Pass |
| Logout                                        | click Logout                          | Session cleared, redirected to Login            | Pass |

This project was manually tested end-to-end (login → upload → generate →
preview → download → previous papers) using a sample Data Structures
syllabus, confirmed to generate valid PDF files and correct database
records.

---

## 11. Viva Questions & Answers

**Q1. What problem does this project solve?**
A. It automates question paper creation for teachers by generating MCQs
directly from an uploaded syllabus, saving manual effort.

**Q2. Why is there no student module?**
A. The project scope is limited to the teacher-facing question generation
workflow; there is no exam-taking or evaluation feature for students.

**Q3. How does the system extract text from PDF/DOCX?**
A. `pdfplumber` reads text per page for PDFs, and `python-docx` reads
paragraph text for DOCX files; both are combined into one string.

**Q4. How are MCQs generated without an external AI API?**
A. Through a rule-based NLP pipeline: keyword extraction using a
frequency × word-length score, followed by sentence-blanking to form
question stems and distractor selection from other keywords.

**Q5. How are wrong options (distractors) chosen?**
A. Three other extracted keywords (different from the correct answer) are
randomly sampled from the syllabus's keyword pool and shuffled with the
correct answer.

**Q6. How does the difficulty level affect the questions?**
A. Difficulty controls which sentences are prioritized: Easy picks
shorter/simpler sentences, Hard picks longer/more complex sentences, and
Medium picks sentences closest to an average length.

**Q7. How are duplicate questions avoided?**
A. The generator tracks which sentences and which keywords have already
been used, and skips them on subsequent matches.

**Q8. What database is used and why?**
A. SQLite, because it is file-based, requires no separate server, and is
sufficient for a single-teacher/small-scale mini project.

**Q9. How is the password stored securely?**
A. Passwords are hashed using Werkzeug's `generate_password_hash` /
`check_password_hash` (PBKDF2-based), never stored in plain text.

**Q10. How is the PDF generated?**
A. Using the ReportLab library's `SimpleDocTemplate`, which lays out
paragraphs and tables (for the answer key) into a formatted PDF file.

**Q11. What is a Flask Blueprint, and why did you use it?**
A. A Blueprint groups related routes into a separate module. Each project
module (login, dashboard, upload, exam, papers) has its own blueprint,
keeping the code organized and easy to navigate.

**Q12. How would you extend this project in the future?**
A. Possible extensions: support for other question types (short answer,
true/false), integration with a real LLM API for higher-quality
questions, teacher-wise paper history, and export to Word format.

---

## 12. Sample Output (from testing)

Uploading a "Data Structures" syllabus and generating 6 Medium-difficulty
MCQs produced fill-in-the-blank style questions such as:

- *"An array is a ______ of elements identified by index or key."*
  Options: (A) Order (B) Vertices (C) Collection (D) Lists — Answer: C
- *"A binary tree is a hierarchical data structure in which each ______
  has at most two children."*
  Options: (A) Linked (B) Bubble (C) Node (D) Elements — Answer: C

Both a Question Paper PDF (with college header, instructions, and
questions) and an Answer Key PDF (tabulated correct answers) were
generated successfully and logged in the `generated_papers` table.
